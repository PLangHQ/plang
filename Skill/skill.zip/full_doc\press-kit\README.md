# Media kit

Here you can find media kit documents.

- [About PLang](./about.md)
- [Fact sheet](./factsheet.md)
- [Press release - 2024-03-12](press-release-2024-03-12.md)
- [Logos](./logos.md)