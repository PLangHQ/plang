# Next Steps

That is it, you have learned everything you need to get started.

Your next steps can be a few:
- You can read our [main documentation page](../README.md)
- You can check out [some example apps to learn](https://github.com/PLangHQ/apps)
- You can check out our [tests for our code](https://github.com/PLangHQ/plang/tree/main/Tests)
- You can check out the [blog](https://ingig.substack.com/) and subscribe for new content

Or if you want to dig deeper into the rabbit hole:

# [Lesson 7 - Security](./Lesson%207.md)
