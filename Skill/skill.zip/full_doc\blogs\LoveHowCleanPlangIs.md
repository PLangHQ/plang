# I love how clean Plang is

I am creating an app. It's a great way to develop the language. If it's not supported and I feel like it works, I will implement it

So I am setting up monitoring on variables in GUI. React style.

It goes like this

```plang
Start
- monitor %number1%, %number2%, call Calculate
/ more code

Calculate
- set %number1% + %number2%, as %sum%
- set #sum = %sum% / we are setting(updating) the GUI
```

So in few lines you are monitoring the variables. Amazing. Plang still blows my mind.

Now I have this project, and I know I am monitoring somewhere variables, so I search for it.

And the results, 3, that is it. And it's clean

![Search results for `monitor`](search_monitor.png)

I just liked that.



