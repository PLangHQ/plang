﻿## Performance in Plang

Plang prioritizes simplicity and ease of use over raw speed, using reflection which adds overhead. Ideal for business apps and automation where rapid development matters more than execution time. Future optimizations aim to boost performance closer to native C# levels.