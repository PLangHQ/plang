﻿## Rules of Plang

Plang is an intuitive programming language using `.goal` files with named goals and steps starting with dashes. It supports variables (%var%), conditional logic via goal calls, loops, modules, and escape characters. Steps can be written flexibly in natural language for clarity.