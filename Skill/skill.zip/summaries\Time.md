﻿## Time Handling in Plang

Plang uses C# DateTime for time operations. Access current time with %Now%/%NowUtc%, set specific dates, modify time by adding/subtracting intervals, use DateTime methods/properties, and format dates with ToString(). Culture settings affect date/time display.