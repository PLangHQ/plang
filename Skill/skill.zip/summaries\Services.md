﻿## Services in PLang

PLang services enable customization via dependency injection, allowing developers to override core functionalities like db, settings, caching, logger, llm, askuser, encryption, and archiver. Services reside in the .services folder and support NuGet integration for extensibility.