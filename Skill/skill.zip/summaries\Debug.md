﻿## Debugging in Plang

Learn to debug Plang code using VS Code with the Plang extension, logger levels, and write-out methods. Also covers debugging generated C# code with Visual Studio and extracting modules. Debug mode slows execution but offers detailed insights via a local server.