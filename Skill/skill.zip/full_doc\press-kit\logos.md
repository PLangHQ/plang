# Logos

## PLang logo
![PLang logo](./logo_w_text.png)

## PLang logo without text

![PLang logo](./logo.png)

