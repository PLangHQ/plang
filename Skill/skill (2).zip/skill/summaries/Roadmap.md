﻿## Roadmap for Plang

Plang's roadmap spans from the current unstable v0.1 with many bugs and untested features, through v0.2 focusing on stability and testing, v0.3 on efficiency improvements, to v0.4 aiming for production readiness by March 2026.