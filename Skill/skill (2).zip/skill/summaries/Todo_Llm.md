﻿## Todo App with LLM

Enhance a Todo app by integrating a Language Learning Model (LLM) to auto-categorize tasks. Learn to modify the database, implement async LLM calls, and test API endpoints for a seamless user experience.