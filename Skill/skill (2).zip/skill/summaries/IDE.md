﻿## Guide to Installing the Plang VS Code Plugin

This guide explains how to install the Plang extension for Visual Studio Code, enabling efficient writing, debugging, and management of Plang code. It covers installation steps, key debugging features, and links to get started with your first Plang app.