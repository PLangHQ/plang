﻿## Events in Plang

Events in Plang enable handling app lifecycle, error management, conditional execution, and build processes. Define events in `Events.goal` to trigger before/after goals, on errors, or variable changes. Supports conditional events and external event integration.