﻿## Using Third-Party Libraries in PLang

Learn how to integrate third-party libraries from NuGet into your PLang projects by downloading, unzipping, and placing the required .dll files into the .services folder. This guide uses Markdig as an example to resolve missing library errors and extend PLang functionality.