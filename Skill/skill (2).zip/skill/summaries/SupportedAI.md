﻿## Supported AI Models in Plang

Plang supports various OpenAI models like gpt-4-turbo and gpt-3.5-turbo with detailed pricing. Developers can customize LLM behavior using parameters such as model, temperature, and scheme. Interaction follows a system-user-assistant structure for flexible AI integration.