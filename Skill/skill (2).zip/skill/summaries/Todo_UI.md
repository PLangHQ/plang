﻿## Todo Window App Tutorial

Learn to transform a Todo web service into a Windows window app using Plang. This step-by-step guide covers app creation, UI layout, goal calls, and running the app. Note: currently Windows-only and in early Alpha stage.