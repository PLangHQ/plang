﻿## Get Started with Plang

This guide helps new Plang users install Plang, set up Visual Studio Code with the Plang extension, and create their first app displaying 'Hello plang world'. It also covers running the app and purchasing a voucher for code execution costs.