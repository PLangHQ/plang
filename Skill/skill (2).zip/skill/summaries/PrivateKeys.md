﻿## Private Keys in Plang

Plang stores unencrypted private keys in a SQLite database with OS-specific default paths. It supports four key types: Identity, Encryption, Blockchain, and Nostr. Exporting keys involves a risk assessment to prevent social engineering. Manual backups are essential in early versions.