﻿## Folder Structure Documentation for Plang

Overview of Plang project folders: Root contains main files and build/db folders; api holds REST services with public goals; ui manages UI files using Bootstrap; events define app events; .modules and .services include DLLs for extending and overriding Plang features.