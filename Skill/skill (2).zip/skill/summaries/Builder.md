﻿## Plang Builder Documentation

This guide explains how Plang Builder processes goal files, using a ReadFile example. It details how steps are parsed, modules selected via LLM, instructions built and validated, enabling automated execution of user intents in Plang.