﻿## CachingHandler Documentation

The CachingHandler in plang enables efficient caching with absolute and sliding time strategies. It supports custom caching backends like Redis via handler injection, allowing flexible and optimized caching tailored to your application's needs.