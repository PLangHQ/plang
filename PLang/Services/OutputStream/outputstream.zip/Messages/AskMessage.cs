﻿using PLang.Attributes;
using PLang.Models;
using System.ComponentModel;
using static PLang.Utils.StepHelper;

namespace PLang.Services.OutputStream.Messages;


[Description(@"
Content can be a filename or a text that will be written to stream, e.g. `render template.html` => Content=""template.html"". 
Target defines where in the UI to write the content, this can be null and will be controlled by external system
Actions are actions executed on the content, built in actions are: 'replace, append, prepend, clear, remove, scrollIntoView, focus, highlight, show, hide, notify, alert, badge, vibrate, navigate, reload, showDialog, showModal'. 
A user can define multiple actions, user:`render 'product.html' to #main, replace the content, navigate and scroll into view => Actions:[""replace"", ""navigate"", ""scrollIntoView""]
Level: trace|debug|info|warning|error|critical. info is default. when user defines a level without a channel, assume channel=log
Channel: default|log|audit|security|metric or custom defined by user
Actor: user|system => user is the default actor when Channel=default, for other channels use system as actor unless defined by user.
CallbackData: %variables% that are sent with the form
OnCallback: Goal to call after recieving an answer.
")]
public sealed record AskMessage(
	[property: Description("file name or general text content or %variable%")]
	string Content,
	[property: Description("set as true when Content looks like a fileName, e.g. %fileName%, %template%, etc. If Content is clearly a text, set as false")]
	bool? IsTemplateFile = null,
	string? Target = null,
	[param: Description("List of action(s) to take, e.g. append, replace, prepend, navigate, etc...")]
	IReadOnlyList<string>? Actions = null,
	string Level = "info",
	int StatusCode = 200,
	string Channel = "default", string Actor = "user",
	[param: LlmIgnore]
	IReadOnlyDictionary<string, object?>? Properties = null,
	Dictionary<string, object?>? CallbackData = null, 
	GoalToCallInfo? OnCallback = null,
	[param: LlmIgnore]
	Callback? Callback = null)
	: OutMessage(
		MessageKind.Ask,
		Level,
		StatusCode,
		Target,
		Actions ?? new[] { "replace" }, Channel, Actor,
		Properties);